"""Application configuration package."""

