from app.authentication_and_identity.authenticated_user_model import AuthenticatedUser


def build_main_menu(user: AuthenticatedUser, opening_only: bool = False) -> str:
    if opening_only:
        return (
            f"👋 Ola, **{user.first_name}**!\n"
            f"Voce esta conectado como **{user.login}** no Suporte TI - Terra Premium.\n\n"
            "Como posso ser util agora?\n\n"
            "Digite o numero da opcao desejada:\n"
            "1️⃣ **Abrir um novo chamado**\n"
            "2️⃣ **Encerrar atendimento**"
        )
    return (
        f"👋 Ola, **{user.first_name}**!\n"
        f"Voce esta conectado como **{user.login}** no Suporte TI - Terra Premium.\n\n"
        "Como posso ser util agora?\n\n"
        "Digite o numero da opcao desejada:\n"
        "1️⃣ **Abrir um novo chamado**\n"
        "2️⃣ **Consultar meus chamados**\n"
        "3️⃣ **Complementar chamado existente**\n"
        "4️⃣ **Encerrar atendimento**"
    )


def build_open_ticket_prompt() -> str:
    return (
        "📝 **Relato da Solicitacao**\n\n"
        "Por favor, descreva abaixo o que esta acontecendo ou o que voce precisa.\n\n"
        "💡 **Dica:** Nao se preocupe com a organizacao agora. Se faltar algum detalhe, eu farei perguntas rapidas para entender melhor.\n\n"
        "Pode digitar sua descricao agora:"
    )


def build_ticket_type_prompt() -> str:
    return (
        "🛠️ **Classificacao da Demanda**\n\n"
        "Para direcionar sua solicitacao ao tecnico correto, selecione o tipo de atendimento:\n\n"
        "1️⃣ **Estou com um problema** (Algo parou de funcionar ou esta com erro)\n"
        "2️⃣ **Preciso de algo novo** (Acessos, equipamentos ou novas instalacoes)\n\n"
        "Digite o numero correspondente:"
    )


def build_description_clarification_message(
    question: str,
    question_number: int,
    max_questions: int,
) -> str:
    return (
        "🔍 **Entendendo Melhor Seu Chamado**\n\n"
        "Quero registrar isso do jeito mais claro possivel para o TI. "
        "Se ainda faltar contexto, posso fazer algumas perguntas rapidas.\n\n"
        f"📋 **Pergunta {question_number} de ate {max_questions}**\n"
        f"{question}\n\n"
        "👉 Responda do jeito que ficar mais natural. Se nao souber, digite **pular**."
    )


def build_category_assignment_message(
    organized_text: str,
    category_id: int,
    category_name: str,
) -> str:
    return (
        "🏷️ **Sugestao de Classificacao**\n\n"
        "Com base no seu relato, identifiquei a seguinte categoria:\n"
        f"📂 **{category_name}**\n\n"
        "Abaixo, veja como organizei seu texto para o tecnico:\n"
        f'"{organized_text}"\n\n'
        "Como deseja prosseguir?\n\n"
        "1️⃣ **Sim, esta correto**\n"
        "2️⃣ **Alterar categoria manualmente**\n"
        "3️⃣ **Reescrever minha descricao**\n"
        "4️⃣ **Cancelar abertura**"
    )


def build_query_menu() -> str:
    return (
        "📂 **Meus Chamados**\n\n"
        "Como voce deseja localizar seus tickets?\n\n"
        "1️⃣ 🟢 **Chamados em aberto**\n"
        "2️⃣ 🔵 **Chamados em atendimento**\n"
        "3️⃣ 🕒 **Ver historico recente**\n"
        "4️⃣ 🔢 **Buscar por numero (ID)**\n"
        "5️⃣ ⬅️ **Voltar ao inicio**"
    )


def build_invalid_option_message() -> str:
    return (
        "⚠️ Nao entendi a opcao. Responda apenas com o **numero** "
        "de uma das opcoes exibidas."
    )


def build_description_review_message(organized_text: str) -> str:
    return (
        "👁️ **Revisao do Chamado**\n\n"
        "Confira como sua solicitacao sera enviada ao tecnico:\n\n"
        f'📝 "{organized_text}"\n\n'
        "O texto reflete bem o seu problema?\n\n"
        "1️⃣ **Sim, continuar**\n"
        "2️⃣ **Nao, quero ajustar o texto**\n"
        "3️⃣ **Usar meu texto original**\n"
        "4️⃣ **Cancelar**"
    )


def build_location_prompt() -> str:
    return (
        "🏢 **Sua Localizacao**\n\n"
        "Para que o tecnico saiba onde atuar, informe sua Unidade e Setor.\n\n"
        "📍 **Exemplo:** Matriz - Financeiro\n\n"
        "Digite sua localizacao abaixo:"
    )


def build_evidence_question() -> str:
    return (
        "📸 **Fotos e Evidencias**\n\n"
        "Voce gostaria de enviar fotos, prints de erro ou documentos para ajudar na analise?\n\n"
        "1️⃣ **Sim, enviar anexos**\n"
        "2️⃣ **Nao, prosseguir sem anexos**"
    )


def build_complement_review_message(rewritten_text: str) -> str:
    return (
        "📝 **Novo Acompanhamento**\n\n"
        "Veja como sua atualizacao sera registrada no chamado:\n\n"
        f'💬 "{rewritten_text}"\n\n'
        "Confirmar envio?\n\n"
        "1️⃣ **Sim, adicionar ao chamado**\n"
        "2️⃣ **Nao, ajustar o texto**\n"
        "3️⃣ **Cancelar**"
    )
